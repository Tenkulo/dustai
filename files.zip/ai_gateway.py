"""
DUST AI – AIGateway v2.0
Layer unificato per chiamate LLM via LiteLLM + OpenRouter + fallback diretti.

Stack (da ricerca comparativa 2026):
  1. LiteLLM SDK (open-source, 100+ provider, Python-nativo, zero markup)
     → gestisce Gemini, Claude, GPT, DeepSeek, Qwen, Mistral, ecc.
  2. OpenRouter (500+ modelli, fallback se LiteLLM non configurato)
  3. Gemini directo (google.generativeai, fallback se LiteLLM non disponibile)
  4. Ollama locale (offline, sempre disponibile)
  5. BrowserAI (playwright, se tutto il resto fallisce)

Perché LiteLLM come layer primario (da ricerca):
  - Zero markup (OpenRouter aggiunge 5%)
  - Self-hosted, privacy totale
  - Routing/fallback/retry built-in
  - Budget guardrails per modello
  - OpenAI-compatible: cambio modello = 1 riga di codice

Installazione:
  pip install litellm
"""

import os
import time
import json
import logging
from pathlib import Path
from typing import Optional

log = logging.getLogger("AIGateway")

# Import da ai_router per metadata modelli
try:
    from .ai_router import MODELS_2026, AIRouter
except ImportError:
    from ai_router import MODELS_2026, AIRouter


class AIGateway:
    """
    Gateway unificato: chiama qualsiasi modello con un'interfaccia sola.
    Gestisce retry, rate limit, fallback automatici.
    """

    def __init__(self, config):
        self.config      = config
        self.router      = AIRouter(config)
        self._litellm_ok = self._init_litellm()
        self._log_dir    = config.get_base_path() / "logs"
        self._log_dir.mkdir(exist_ok=True)
        self._usage_log  = self._log_dir / "gateway_usage.jsonl"
        self._browser_ai = None   # lazy init

        # Configura budget LiteLLM se disponibile
        if self._litellm_ok:
            self._setup_litellm_budgets()

    # ─── Call pubblica ─────────────────────────────────────────────────────────

    def call(self, model_id: str, prompt: str,
             system: str = "",
             max_tokens: int = 2000,
             temperature: float = 0.7,
             retry_on_429: bool = True) -> dict:
        """
        Chiama un modello specifico.
        Ritorna: {"ok": bool, "text": str, "model_id": str,
                  "tokens": dict, "latency_s": float}
        """
        meta   = MODELS_2026.get(model_id, {})
        start  = time.time()

        # ── Routing per provider ──────────────────────────────────────────────
        provider = meta.get("provider", "")

        # 1. Ollama locale
        if model_id.startswith("ollama/") or provider == "ollama_local":
            return self._call_ollama(model_id, prompt, system, max_tokens)

        # 2. LiteLLM (via litellm_id)
        litellm_id = meta.get("litellm_id")
        if litellm_id and self._litellm_ok:
            return self._call_litellm(litellm_id, prompt, system,
                                      max_tokens, temperature, retry_on_429)

        # 3. Gemini diretto (fallback se LiteLLM non installato)
        if model_id.startswith("gemini/") or provider == "google":
            return self._call_gemini_direct(
                model_id.replace("gemini/", ""), prompt, system, max_tokens)

        # 4. OpenRouter diretto (fallback finale per modelli non-Google)
        openrouter_id = meta.get("openrouter_id")
        if openrouter_id:
            return self._call_openrouter_direct(
                openrouter_id, prompt, system, max_tokens)

        return {"ok": False,
                "error": "Nessun provider disponibile per: " + model_id,
                "model_id": model_id}

    def call_auto(self, prompt: str, task_type: str = "auto",
                  mode: str = "best") -> dict:
        """
        Chiama il modello ottimale scelto automaticamente dal router.
        Cascade automatico su fallimento.
        """
        if task_type == "auto":
            task_type = self.router.classify(prompt)

        models = self.router.get_route(task_type, mode)
        log.info("auto call: task=" + task_type + " route=" +
                 str([m.split("/")[-1] for m in models]))

        for model_id in models:
            t0     = time.time()
            result = self.call(model_id, prompt)
            latency = round(time.time() - t0, 2)

            if result.get("ok"):
                self.router.record(model_id, task_type, True, latency)
                self._log_usage(model_id, task_type, True, latency,
                                len(result.get("text", "")))
                return result

            err = result.get("error", "")
            self.router.record(model_id, task_type, False, latency)

            # Rate limit → cooldown e prova prossimo
            if "429" in err or "RATE" in err.upper() or "RESOURCE_EXHAUSTED" in err:
                self.router.set_cooldown(model_id, 65)
                log.warning(model_id.split("/")[-1] + " → 429, provo il prossimo")
                continue

            # Altro errore → prova prossimo comunque
            log.warning(model_id.split("/")[-1] + " → " + err[:100])

        return {"ok": False,
                "error": "Tutti i modelli hanno fallito per task: " + task_type,
                "task_type": task_type}

    # ─── LiteLLM ─────────────────────────────────────────────────────────────

    def _call_litellm(self, litellm_id: str, prompt: str, system: str,
                      max_tokens: int, temperature: float,
                      retry_on_429: bool) -> dict:
        try:
            from litellm import completion
            import litellm
            litellm.suppress_debug_info = True

            msgs = []
            if system:
                msgs.append({"role": "system", "content": system})
            msgs.append({"role": "user", "content": prompt})

            resp  = completion(
                model       = litellm_id,
                messages    = msgs,
                max_tokens  = max_tokens,
                temperature = temperature,
                timeout     = 60,
                num_retries = 2 if retry_on_429 else 0,
            )
            text   = resp.choices[0].message.content or ""
            usage  = resp.usage or type("U", (), {"prompt_tokens": 0,
                                                   "completion_tokens": 0})()
            return {
                "ok":      True,
                "text":    text.strip(),
                "model_id": litellm_id,
                "tokens":  {"in":  getattr(usage, "prompt_tokens", 0),
                             "out": getattr(usage, "completion_tokens", 0)},
            }

        except Exception as e:
            err = str(e)
            code = "429" if ("429" in err or
                             "rate" in err.lower() or
                             "RESOURCE_EXHAUSTED" in err) else "error"
            return {"ok": False, "error": err[:300],
                    "error_code": code, "model_id": litellm_id}

    # ─── Gemini diretto ───────────────────────────────────────────────────────

    def _call_gemini_direct(self, model_name: str, prompt: str,
                            system: str, max_tokens: int) -> dict:
        try:
            import google.generativeai as genai
            api_key = (os.environ.get("GOOGLE_API_KEY") or
                       os.environ.get("GOOGLE_API_KEY_2") or
                       os.environ.get("GOOGLE_API_KEY_3", ""))
            if not api_key:
                return {"ok": False, "error": "GOOGLE_API_KEY mancante",
                        "model_id": "gemini/" + model_name}

            genai.configure(api_key=api_key)
            m = genai.GenerativeModel(
                model_name=model_name,
                system_instruction=system or None,
            )
            resp = m.generate_content(
                prompt,
                generation_config=genai.types.GenerationConfig(
                    max_output_tokens=max_tokens
                ),
            )
            try:
                text = resp.text.strip()
            except Exception:
                text = ""
            if not text:
                return {"ok": False, "error": "Risposta vuota (finish_reason="
                        + str(getattr(resp.candidates[0], "finish_reason", "?"))
                        + ")", "model_id": "gemini/" + model_name}
            return {"ok": True, "text": text,
                    "model_id": "gemini/" + model_name}
        except Exception as e:
            return {"ok": False, "error": str(e)[:300],
                    "model_id": "gemini/" + model_name}

    # ─── OpenRouter diretto ───────────────────────────────────────────────────

    def _call_openrouter_direct(self, openrouter_model: str, prompt: str,
                                system: str, max_tokens: int) -> dict:
        try:
            import requests
            api_key = os.environ.get("OPENROUTER_API_KEY", "")
            if not api_key:
                return {"ok": False, "error": "OPENROUTER_API_KEY mancante",
                        "model_id": "openrouter/" + openrouter_model}

            msgs = []
            if system:
                msgs.append({"role": "system", "content": system})
            msgs.append({"role": "user", "content": prompt})

            resp = requests.post(
                "https://openrouter.ai/api/v1/chat/completions",
                headers={
                    "Authorization": "Bearer " + api_key,
                    "Content-Type": "application/json",
                },
                json={
                    "model":      openrouter_model,
                    "messages":   msgs,
                    "max_tokens": max_tokens,
                },
                timeout=60,
            )
            data = resp.json()
            if resp.status_code != 200:
                return {"ok": False,
                        "error": str(data.get("error", resp.text))[:300],
                        "model_id": "openrouter/" + openrouter_model}

            text = data["choices"][0]["message"]["content"] or ""
            return {"ok": True, "text": text.strip(),
                    "model_id": "openrouter/" + openrouter_model}

        except Exception as e:
            return {"ok": False, "error": str(e)[:300],
                    "model_id": "openrouter/" + openrouter_model}

    # ─── Ollama ───────────────────────────────────────────────────────────────

    def _call_ollama(self, model_id: str, prompt: str,
                     system: str, max_tokens: int) -> dict:
        model_name = model_id.replace("ollama/", "")
        try:
            import ollama
            msgs = []
            if system:
                msgs.append({"role": "system", "content": system})
            msgs.append({"role": "user", "content": prompt})
            resp = ollama.chat(
                model=model_name,
                messages=msgs,
                options={"num_predict": max_tokens, "temperature": 0.7},
                stream=False,
            )
            text = resp["message"]["content"].strip()
            return {"ok": True, "text": text, "model_id": model_id}
        except Exception as e:
            return {"ok": False, "error": str(e)[:300], "model_id": model_id}

    # ─── LiteLLM setup ────────────────────────────────────────────────────────

    def _init_litellm(self) -> bool:
        try:
            import litellm
            # Configura API keys da env
            os.environ.setdefault("GEMINI_API_KEY",
                                  os.environ.get("GOOGLE_API_KEY", ""))
            log.info("LiteLLM disponibile")
            return True
        except ImportError:
            log.warning("LiteLLM non installato → pip install litellm")
            return False

    def _setup_litellm_budgets(self):
        """Configura budget giornalieri per evitare spese eccessive."""
        try:
            import litellm
            # Limite di spesa: €5/giorno totale
            litellm.max_budget = 5.0
            litellm.budget_duration = "1d"
        except Exception:
            pass

    # ─── Usage log ────────────────────────────────────────────────────────────

    def _log_usage(self, model_id: str, task_type: str,
                   success: bool, latency: float, chars: int):
        from datetime import datetime
        entry = {
            "ts":       datetime.now().isoformat(),
            "model":    model_id,
            "task":     task_type,
            "ok":       success,
            "latency":  latency,
            "chars":    chars,
        }
        try:
            with open(self._usage_log, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception:
            pass

    def status_report(self) -> str:
        lines = [
            "=== AIGateway Status ===",
            "LiteLLM: " + ("✅ attivo" if self._litellm_ok else
                           "❌ mancante (pip install litellm)"),
            "OpenRouter: " + ("✅" if os.environ.get("OPENROUTER_API_KEY")
                               else "❌ OPENROUTER_API_KEY mancante"),
            "Gemini: " + ("✅" if os.environ.get("GOOGLE_API_KEY")
                          else "❌ GOOGLE_API_KEY mancante"),
            "Ollama: locale (sempre disponibile)",
            "",
        ]
        lines.append(self.router.stats_report())
        return "\n".join(lines)
