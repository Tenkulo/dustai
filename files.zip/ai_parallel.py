"""
DUST AI – AIParallel v2.0
Esecuzione parallela su N modelli con consensus/sintesi.

Pattern implementati (da ricerca 2026):
  - Fan-out / Fan-in (Google ADK, Azure AI patterns)
  - ReConcile round-table voting (ACL 2024)
  - SMoA Sparse Mixture of Agents
  - Circuit breaker per rate limit
  - A2A Agent-to-Agent response chaining (AgentScope 2026)

Flusso:
  1. Fan-out: invia prompt a N modelli in parallelo (ThreadPoolExecutor)
  2. Collect: raccoglie risposte entro timeout
  3. Judge: valuta qualità di ogni risposta
  4. Consensus: aggrega / vota / sintetizza
  5. Return: ritorna risposta migliore + metadati
"""

import time
import logging
import json
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional

log = logging.getLogger("AIParallel")


class AIParallel:
    """
    Motore di esecuzione parallela multi-modello.
    """

    def __init__(self, config, gateway):
        """
        config:  Config DUST
        gateway: AIGateway (gestisce le chiamate ai modelli)
        """
        self.config        = config
        self.gateway       = gateway
        self._results_dir  = config.get_base_path() / "ai_responses"
        self._results_dir.mkdir(exist_ok=True)

    # ─── API pubblica ──────────────────────────────────────────────────────────

    def run(self, prompt: str, models: list,
            timeout: int = 45,
            min_responses: int = 1) -> dict:
        """
        Esegui prompt su N modelli in parallelo.
        Ritorna il risultato con consensus o miglior risposta.

        Args:
          prompt:        testo da inviare
          models:        lista di model_id
          timeout:       secondi massimi di attesa totale
          min_responses: risposte minime per procedere (default 1)
        """
        if not models:
            return {"ok": False, "error": "Nessun modello specificato"}

        log.info("Parallel fan-out su " + str(len(models)) + " modelli: " +
                 str([m.split("/")[-1] for m in models]))

        start    = time.time()
        results  = {}
        errors   = {}

        # ── Fan-out parallelo ─────────────────────────────────────────────────
        with ThreadPoolExecutor(max_workers=min(len(models), 6)) as ex:
            futures = {
                ex.submit(self._call_with_meta, m, prompt): m
                for m in models
            }

            for future in as_completed(futures, timeout=timeout):
                model_id = futures[future]
                try:
                    result = future.result(timeout=5)
                    if result.get("ok"):
                        results[model_id] = result
                        elapsed = round(time.time() - start, 1)
                        log.info("  ✓ " + model_id.split("/")[-1] +
                                 " in " + str(elapsed) + "s " +
                                 "(" + str(len(result.get("text", ""))) + " chars)")
                    else:
                        errors[model_id] = result.get("error", "unknown")
                        log.warning("  ✗ " + model_id.split("/")[-1] +
                                    ": " + str(errors[model_id])[:80])
                except Exception as e:
                    errors[model_id] = str(e)
                    log.warning("  ✗ " + model_id.split("/")[-1] + " exception: " + str(e)[:80])

        total_time = round(time.time() - start, 1)

        # ── Verifica risultati minimi ─────────────────────────────────────────
        if len(results) < min_responses:
            if errors:
                first_error = list(errors.values())[0]
                return {"ok": False,
                        "error": "Solo " + str(len(results)) + "/" +
                                 str(len(models)) + " modelli hanno risposto. " +
                                 "Primo errore: " + str(first_error),
                        "partial_results": results}
            return {"ok": False, "error": "Nessuna risposta ricevuta"}

        # ── Fan-in: consensus/sintesi ─────────────────────────────────────────
        consensus = self._consensus(prompt, results)
        consensus["parallel_time_s"]   = total_time
        consensus["models_queried"]     = len(models)
        consensus["models_responded"]   = len(results)
        consensus["models_failed"]      = errors

        # Salva risultati per analisi futura
        self._save_parallel_result(prompt, results, consensus)

        return consensus

    # ─── Chiamata singolo modello con metadata ────────────────────────────────

    def _call_with_meta(self, model_id: str, prompt: str) -> dict:
        """Chiama un modello e aggiunge metadati di timing."""
        start  = time.time()
        result = self.gateway.call(model_id, prompt)
        result["latency_s"] = round(time.time() - start, 2)
        result["model_id"]  = model_id
        return result

    # ─── Consensus (fan-in) ────────────────────────────────────────────────────

    def _consensus(self, prompt: str, results: dict) -> dict:
        """
        Aggrega risposte multiple.

        Algoritmo (ispirato a ReConcile + SMoA):
          1 risposta:  ritorna diretto
          2-3:         vota per qualità + accordo semantico
          4+:          sintetizza con meta-modello
        """
        n = len(results)

        if n == 1:
            only = list(results.values())[0]
            return {
                "ok":            True,
                "text":          only["text"],
                "model":         only["model_id"],
                "consensus":     "single",
                "parallel_count": 1,
            }

        texts = {mid: r["text"] for mid, r in results.items()}

        # ── Scoring qualità per ogni risposta ────────────────────────────────
        scores = self._score_responses(texts)

        # ── Accordo semantico ─────────────────────────────────────────────────
        agreement = self._semantic_agreement(list(texts.values()))

        log.info("Consensus: " + str(n) + " risposte, "
                 "accordo=" + str(round(agreement, 2)) + ", "
                 "top=" + str(scores[0][0]).split("/")[-1])

        if agreement >= 0.40 or n <= 2:
            # Alta concordanza: usa la risposta con score migliore
            best_model, best_score = scores[0]
            return {
                "ok":            True,
                "text":          texts[best_model],
                "model":         best_model,
                "consensus":     "agreement",
                "agreement":     round(agreement, 2),
                "parallel_count": n,
                "all_models":    list(texts.keys()),
                "quality_scores": {m: round(s, 2) for m, s in scores},
            }

        # Bassa concordanza: sintesi via meta-modello
        return self._synthesize(prompt, texts, scores, agreement)

    def _score_responses(self, texts: dict) -> list:
        """
        Punteggio semplice per ogni risposta.
        Criteri: lunghezza, struttura, completezza, codice.
        Ritorna lista ordinata [(model_id, score), ...]
        """
        scores = {}
        for model_id, text in texts.items():
            s = 0.0

            # Lunghezza (max 2 punti)
            words = len(text.split())
            s += min(words / 200, 2.0)

            # Ha codice (valore aggiunto per task tecnici)
            if "```" in text or "def " in text or "import " in text:
                s += 0.5

            # Ha struttura (headers, bullets)
            if "\n#" in text or "\n-" in text or "\n*" in text:
                s += 0.3

            # Non è troncato
            if not text.rstrip().endswith("...") and len(text) > 50:
                s += 0.2

            scores[model_id] = s

        return sorted(scores.items(), key=lambda x: x[1], reverse=True)

    def _semantic_agreement(self, texts: list) -> float:
        """
        Misura accordo semantico tra risposte (overlap parole chiave).
        Ritorna 0.0 (nessun accordo) → 1.0 (accordo totale).
        """
        if len(texts) < 2:
            return 1.0

        def keywords(text):
            stopwords = {"il","lo","la","i","gli","le","un","uno","una",
                         "di","a","da","in","con","su","per","tra","fra",
                         "the","a","an","is","are","was","were","be","been",
                         "and","or","but","in","on","at","to","for","of"}
            return {w.lower() for w in text.split()
                    if len(w) > 3 and w.lower() not in stopwords}

        sets = [keywords(t) for t in texts]
        base = sets[0]
        for s in sets[1:]:
            if not base and not s:
                continue
            intersection = base & s
            union        = base | s
            base         = intersection   # iterativo
            if not union:
                return 1.0
            final_union = sets[0] | sets[-1]
            if not final_union:
                return 0.0
            return len(intersection) / len(final_union)
        return 0.0

    def _synthesize(self, prompt: str, texts: dict,
                    scores: list, agreement: float) -> dict:
        """
        Sintesi meta-modello quando le risposte divergono.
        Usa il modello più veloce disponibile (Gemini Flash).
        """
        top_models = [m for m, _ in scores[:3]]

        synthesis_prompt = (
            "Sei un meta-analista AI. Hai ricevuto risposte diverse alla stessa domanda "
            "da modelli differenti. Sintetizza una risposta UNICA, ACCURATA e COMPLETA.\n\n"
            "DOMANDA ORIGINALE:\n" + prompt[:600] + "\n\n"
        )
        for i, (model_id, text) in enumerate(
                [(m, texts[m]) for m in top_models if m in texts], 1):
            display = model_id.split("/")[-1]
            synthesis_prompt += (
                "── Risposta " + str(i) + " [" + display + "] ──\n"
                + text[:800] + "\n\n"
            )
        synthesis_prompt += (
            "── SINTESI ──\n"
            "Combina le informazioni migliori di ogni risposta. "
            "Risolvi contraddizioni. Sii preciso e completo."
        )

        synth_result = self.gateway.call(
            "gemini/gemini-2.5-flash", synthesis_prompt
        )

        if synth_result.get("ok"):
            return {
                "ok":            True,
                "text":          synth_result["text"],
                "model":         "synthesis[" + "+".join(
                                     m.split("/")[-1] for m in top_models) + "]",
                "consensus":     "synthesized",
                "agreement":     round(agreement, 2),
                "parallel_count": len(texts),
                "all_models":    list(texts.keys()),
                "synthesized":   True,
            }

        # Fallback: usa risposta con score migliore
        best_model = scores[0][0]
        return {
            "ok":            True,
            "text":          texts[best_model],
            "model":         best_model,
            "consensus":     "fallback_best",
            "agreement":     round(agreement, 2),
            "parallel_count": len(texts),
        }

    # ─── Persistenza ─────────────────────────────────────────────────────────

    def _save_parallel_result(self, prompt: str,
                               results: dict, consensus: dict):
        ts   = datetime.now().strftime("%Y%m%d_%H%M%S")
        data = {
            "ts":         datetime.now().isoformat(),
            "prompt":     prompt[:300],
            "models":     list(results.keys()),
            "consensus":  consensus.get("consensus"),
            "agreement":  consensus.get("agreement"),
            "response":   consensus.get("text", "")[:500],
        }
        try:
            f = self._results_dir / ("parallel_" + ts + ".json")
            f.write_text(json.dumps(data, ensure_ascii=False, indent=2),
                         encoding="utf-8")
        except Exception:
            pass
