"""
DUST AI – install_orchestra.py
Installa e configura il sistema AIOrchestra su A:\\dustai.

Esegui: python A:\\dustai\\install_orchestra.py

Cosa fa:
  1. Installa dipendenze Python (litellm, requests)
  2. Copia i nuovi file src/ nel repo
  3. Patcha registry.py per registrare i nuovi tool
  4. Patcha agent.py per usare AIConductor
  5. Aggiorna .env con template chiavi API
  6. Commit e push su GitHub
"""
import subprocess
import sys
import shutil
import ast
import json
import time
from pathlib import Path

BASE      = Path(r"A:\dustai")
SRC       = BASE / "src"
STUFF     = Path(r"A:\dustai_stuff")
BAK       = STUFF / "patches"
DOWNLOADS = Path.home() / "Downloads"

print("=" * 60)
print("DUST AI – Orchestra v2.0 Setup")
print("=" * 60)

# ── Step 1: Dipendenze ────────────────────────────────────────────────────────
print("\n[1/6] Installazione dipendenze...")

deps = ["litellm", "requests", "pyperclip"]
for dep in deps:
    print("  pip install " + dep + "...")
    r = subprocess.run(
        [sys.executable, "-m", "pip", "install", dep, "--quiet"],
        capture_output=True, text=True
    )
    if r.returncode == 0:
        print("  ✅ " + dep)
    else:
        print("  ⚠️  " + dep + " (potrebbe già essere installato)")

# ── Step 2: Copia file nuovi ──────────────────────────────────────────────────
print("\n[2/6] Copia file orchestra in A:\\dustai\\src\\...")

NEW_FILES = [
    "ai_router.py",
    "ai_gateway.py",
    "ai_parallel.py",
    "github_sync.py",
    "ai_conductor.py",
]

for fname in NEW_FILES:
    src_file = DOWNLOADS / fname
    dst_file = SRC / fname
    if src_file.exists():
        shutil.copy2(src_file, dst_file)
        print("  ✅ " + fname)
    else:
        print("  ⚠️  " + fname + " non trovato in Downloads – copia manualmente in " + str(SRC))

# ── Step 3: Patcha registry.py ────────────────────────────────────────────────
print("\n[3/6] Patch registry.py...")

REGISTRY = SRC / "tools" / "registry.py"
if REGISTRY.exists():
    reg_src = REGISTRY.read_text(encoding="utf-8")
    BAK.mkdir(parents=True, exist_ok=True)
    shutil.copy2(REGISTRY, BAK / ("registry.bak_" + str(int(time.time())) + ".py"))

    CONDUCTOR_TOOLS = '''
    # ── AIConductor tools (orchestra v2.0) ──────────────────────────────────
    def _get_conductor(self):
        if not hasattr(self, "_conductor_inst"):
            try:
                from ..ai_conductor import AIConductorTool
                self._conductor_inst = AIConductorTool(self.config)
            except Exception as e:
                self._conductor_inst = None
                self._failed["conductor"] = str(e)
        return self._conductor_inst

    def _get_git_sync(self):
        if not hasattr(self, "_git_sync_inst"):
            try:
                from ..github_sync import GitSyncTool
                self._git_sync_inst = GitSyncTool(self.config)
            except Exception as e:
                self._git_sync_inst = None
                self._failed["git_sync"] = str(e)
        return self._git_sync_inst

'''

    # Aggiungi metodi se non esistono
    if "_get_conductor" not in reg_src:
        # Inserisci prima dell'ultimo metodo execute
        insert_point = "    def execute(self"
        if insert_point in reg_src:
            reg_src = reg_src.replace(insert_point,
                                      CONDUCTOR_TOOLS + insert_point, 1)
            print("  ✅ _get_conductor / _get_git_sync aggiunti")

    # Aggiungi dispatch
    DISPATCH_ADD = '''
            # Orchestra AI tools
            "ai_ask":        lambda p: (self._get_conductor().ai_ask(**p)
                                         if self._get_conductor() else "conductor N/D"),
            "ai_parallel":   lambda p: (self._get_conductor().ai_parallel(**p)
                                         if self._get_conductor() else "conductor N/D"),
            "ai_status":     lambda p: (self._get_conductor().ai_status()
                                         if self._get_conductor() else "conductor N/D"),
            "ai_models":     lambda p: (self._get_conductor().ai_models(**p)
                                         if self._get_conductor() else "conductor N/D"),
            "git_sync":      lambda p: (self._get_git_sync().git_sync(**p)
                                         if self._get_git_sync() else "git N/D"),
            "git_commit":    lambda p: (self._get_git_sync().git_commit(**p)
                                         if self._get_git_sync() else "git N/D"),
            "git_status":    lambda p: (self._get_git_sync().git_status()
                                         if self._get_git_sync() else "git N/D"),
            "git_push":      lambda p: (self._get_git_sync().git_push()
                                         if self._get_git_sync() else "git N/D"),
'''

    if '"ai_ask"' not in reg_src:
        # Inserisci nel dispatch (cerca "browser_open" o altra entry)
        search_anchor = '"sys_exec":'
        if search_anchor in reg_src:
            reg_src = reg_src.replace(search_anchor,
                                      '"sys_exec":' + DISPATCH_ADD, 1)
            print("  ✅ Dispatch tool aggiunti (ai_ask, ai_parallel, git_sync, ...)")

    # Verifica sintassi
    try:
        ast.parse(reg_src)
        REGISTRY.write_text(reg_src, encoding="utf-8")
        print("  ✅ registry.py sintassi OK, salvato")
    except SyntaxError as e:
        print("  ❌ ERRORE sintassi registry.py: " + str(e))
        print("     Ripristino backup...")
        shutil.copy2(BAK / ("registry.bak_" + str(int(time.time() - 1)) + ".py"),
                     REGISTRY)
else:
    print("  ⚠️  registry.py non trovato in " + str(REGISTRY))

# ── Step 4: Aggiorna .env ─────────────────────────────────────────────────────
print("\n[4/6] Aggiornamento .env...")

ENV_FILE = STUFF / ".env"
if ENV_FILE.exists():
    env_content = ENV_FILE.read_text(encoding="utf-8")
else:
    env_content = ""

ENV_ADDITIONS = """
# ── AI Orchestra v2.0 – API Keys ────────────────────────────────────────────
# OpenRouter: accesso a 500+ modelli (Claude, GPT, DeepSeek, Qwen, Mistral...)
# Registrati su openrouter.ai – free tier disponibile
OPENROUTER_API_KEY=

# Google Gemini – 3 progetti separati = 3x quota gratuita
# AI Studio: aistudio.google.com → Get API key
GOOGLE_API_KEY=         # Progetto 1 – primario (Gemini Flash)
GOOGLE_API_KEY_2=       # Progetto 2 – fast/lite
GOOGLE_API_KEY_3=       # Progetto 3 – Gemini Pro

# Opzionale: Perplexity per web search
PERPLEXITY_API_KEY=
"""

if "OPENROUTER_API_KEY" not in env_content:
    with open(ENV_FILE, "a", encoding="utf-8") as f:
        f.write("\n" + ENV_ADDITIONS)
    print("  ✅ Chiavi AI Orchestra aggiunte a .env")
    print("     📝 Apri A:\\dustai_stuff\\.env e inserisci le tue chiavi!")
else:
    print("  ✅ .env già configurato")

# ── Step 5: Aggiorna TOOL_SCHEMAS in agent.py ─────────────────────────────────
print("\n[5/6] Aggiornamento TOOL_SCHEMAS in agent.py...")

AGENT = SRC / "agent.py"
if AGENT.exists():
    ag_src = AGENT.read_text(encoding="utf-8")

    NEW_SCHEMAS = """
    {"name": "ai_ask",
     "description": "Interroga la miglior AI per il task. Usa questo per domande complesse che richiedono ragionamento avanzato.",
     "parameters": {"type": "object", "properties": {
         "prompt": {"type": "string", "description": "La domanda o il task"},
         "model":  {"type": "string", "description": "auto|gemini|gemini3|claude|gpt|codex|grok|deepseek|qwen|ollama|free"},
         "mode":   {"type": "string", "description": "auto|best|cascade|free_only"},
     }, "required": ["prompt"]}},
    {"name": "ai_parallel",
     "description": "Esegui lo stesso prompt su più AI in parallelo e ottieni il consensus. Usa per decisioni importanti.",
     "parameters": {"type": "object", "properties": {
         "prompt": {"type": "string"},
         "models": {"type": "string", "description": "es. 'gemini,claude,gpt' o '' per auto"},
     }, "required": ["prompt"]}},
    {"name": "ai_models",
     "description": "Lista i modelli AI disponibili.",
     "parameters": {"type": "object", "properties": {
         "filter_available": {"type": "string", "description": "all|available|free"},
     }, "required": []}},
    {"name": "git_sync",
     "description": "Sincronizza DUST con GitHub (pull + commit + push).",
     "parameters": {"type": "object", "properties": {
         "message": {"type": "string"},
     }, "required": []}},
    {"name": "git_commit",
     "description": "Committa le modifiche correnti su GitHub.",
     "parameters": {"type": "object", "properties": {
         "message": {"type": "string"},
     }, "required": ["message"]}},
    {"name": "git_status",
     "description": "Stato del repository GitHub.",
     "parameters": {"type": "object", "properties": {}, "required": []}},
"""

    if '"ai_ask"' not in ag_src and "TOOL_SCHEMAS" in ag_src:
        # Trova fine lista TOOL_SCHEMAS e aggiungi prima della chiusura
        idx = ag_src.rfind("]", ag_src.find("TOOL_SCHEMAS"))
        if idx > 0:
            ag_src = ag_src[:idx] + NEW_SCHEMAS + ag_src[idx:]
            try:
                ast.parse(ag_src)
                AGENT.write_text(ag_src, encoding="utf-8")
                print("  ✅ TOOL_SCHEMAS aggiornato")
            except SyntaxError as e:
                print("  ❌ ERRORE sintassi agent.py: " + str(e))
    else:
        print("  ✅ TOOL_SCHEMAS già aggiornato")

# ── Step 6: Commit e push ─────────────────────────────────────────────────────
print("\n[6/6] Commit e push su GitHub...")

import subprocess
from datetime import datetime

ts  = datetime.now().strftime("%Y-%m-%d %H:%M")
msg = "feat: AIOrchestra v2.0 – router+gateway+parallel+sync (" + ts + ")"

cmds = [
    ["git", "add", "-A"],
    ["git", "commit", "-m", msg],
    ["git", "push", "origin", "master"],
]

for cmd in cmds:
    r = subprocess.run(cmd, cwd=str(BASE), capture_output=True,
                       text=True, encoding="utf-8")
    label = " ".join(cmd[:2])
    if r.returncode == 0:
        print("  ✅ " + label)
    else:
        out = (r.stderr or r.stdout or "errore")[:200]
        if "nothing to commit" in out or "up to date" in out:
            print("  ✅ " + label + " (già aggiornato)")
        else:
            print("  ⚠️  " + label + ": " + out)

print("""
╔══════════════════════════════════════════════════════════╗
║  DUST AI Orchestra v2.0 – INSTALLAZIONE COMPLETATA      ║
╠══════════════════════════════════════════════════════════╣
║                                                          ║
║  PROSSIMI PASSI:                                         ║
║                                                          ║
║  1. Aggiungi le chiavi API in A:\\dustai_stuff\\.env:      ║
║     - OPENROUTER_API_KEY  (500+ modelli)                 ║
║     - GOOGLE_API_KEY      (Gemini, gratuito)             ║
║     - GOOGLE_API_KEY_2    (secondo progetto, free)       ║
║     - GOOGLE_API_KEY_3    (terzo progetto, free)         ║
║                                                          ║
║  2. Usa i nuovi tool nella GUI DUST:                     ║
║     ai_ask prompt="spiega questo codice" model=claude    ║
║     ai_parallel prompt="qual è la soluzione migliore?"  ║
║     ai_models filter_available=free                      ║
║     git_sync message="update"                            ║
║                                                          ║
║  3. DUST ora sceglie autonomamente il modello ottimale!  ║
╚══════════════════════════════════════════════════════════╝
""")
