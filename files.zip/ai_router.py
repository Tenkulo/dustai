"""
DUST AI – AIRouter v2.0
Routing intelligente basato su benchmark reali Marzo 2026.

Fonti ricerca:
  - ArtificialAnalysis Intelligence Index (Mar 2026)
  - LMCouncil benchmarks (Mar 2026)
  - DesignForOnline model guide (Mar 2026)
  - VirtusLab best models Jan 2026

Top 5 per Intelligence Index (Mar 2026):
  1. Gemini 3.1 Pro Preview (score 57)
  2. GPT-5.4 xhigh        (score 57)
  3. GPT-5.3 Codex        (score 54)
  4. Claude Opus 4.6      (score 53)
  5. Claude Sonnet 4.6    (score 52)

Gateway strategy (da ricerca):
  - LiteLLM SDK (open-source, Python, 100+ provider) = layer primario
  - OpenRouter (500+ modelli, zero infra, pagamento a consumo) = backend
  - Ollama (offline, privacy, no rate limit) = fallback locale

Routing pattern: SkillOrchestra (paper 2026) + SMoA (Sparse Mixture of Agents)
"""

import os
import json
import time
import logging
from pathlib import Path
from typing import Optional

log = logging.getLogger("AIRouter")

# ─── Catalogo modelli Marzo 2026 ──────────────────────────────────────────────
# Fonte: artificialanalysis.ai + designforonline.com + lmcouncil.ai

MODELS_2026 = {

    # ══ TIER 1 – Frontier ═════════════════════════════════════════════════════

    "gemini/gemini-2.5-flash": {
        "display":      "Gemini 2.5 Flash",
        "provider":     "google",
        "tier":         1,
        "intelligence": 49,                          # ArtificialAnalysis index
        "speed_tps":    150,
        "cost_in":      0.075,                       # $/1M tokens
        "cost_out":     0.30,
        "context_k":    1000,
        "free_tier":    True,
        "rpm_free":     15,
        "rpd_free":     1500,
        "api_key_env":  "GOOGLE_API_KEY",
        "strengths":    ["general", "vision", "speed", "free", "function_calling"],
        "weaknesses":   ["deep_reasoning"],
        "litellm_id":   "gemini/gemini-2.5-flash",
        "openrouter_id":"google/gemini-2.5-flash",
    },

    "gemini/gemini-3.1-pro": {
        "display":      "Gemini 3.1 Pro",
        "provider":     "google",
        "tier":         1,
        "intelligence": 57,                          # #1 Intelligence Index Mar 2026
        "speed_tps":    80,
        "cost_in":      2.0,
        "cost_out":     12.0,
        "context_k":    2000,
        "free_tier":    True,
        "rpm_free":     5,
        "rpd_free":     50,
        "api_key_env":  "GOOGLE_API_KEY_3",
        "strengths":    ["reasoning", "math", "coding", "vision", "benchmark_leader", "context_2m"],
        "weaknesses":   ["cost", "rate_limited_free"],
        "litellm_id":   "gemini/gemini-3.1-pro",
        "openrouter_id":"google/gemini-3.1-pro",
    },

    "openrouter/anthropic/claude-sonnet-4-6": {
        "display":      "Claude Sonnet 4.6",
        "provider":     "anthropic",
        "tier":         1,
        "intelligence": 52,                          # #5 Intelligence Index
        "speed_tps":    90,
        "cost_in":      3.0,
        "cost_out":     15.0,
        "context_k":    200,
        "free_tier":    False,
        "api_key_env":  "OPENROUTER_API_KEY",
        "strengths":    ["coding", "refactoring", "analysis", "swebench_leader", "reliability"],
        "weaknesses":   ["cost", "no_free_tier"],
        "litellm_id":   "openrouter/anthropic/claude-sonnet-4-6",
        "openrouter_id":"anthropic/claude-sonnet-4-6",
    },

    "openrouter/anthropic/claude-opus-4-6": {
        "display":      "Claude Opus 4.6",
        "provider":     "anthropic",
        "tier":         1,
        "intelligence": 53,                          # #4 Intelligence Index
        "speed_tps":    40,
        "cost_in":      15.0,
        "cost_out":     75.0,
        "context_k":    200,
        "free_tier":    False,
        "api_key_env":  "OPENROUTER_API_KEY",
        "strengths":    ["complex_reasoning", "deep_analysis", "long_context"],
        "weaknesses":   ["very_expensive", "slow"],
        "litellm_id":   "openrouter/anthropic/claude-opus-4-6",
        "openrouter_id":"anthropic/claude-opus-4-6",
    },

    "openrouter/openai/gpt-5.2": {
        "display":      "GPT-5.2",
        "provider":     "openai",
        "tier":         1,
        "intelligence": 55,                          # benchmark leader
        "speed_tps":    70,
        "cost_in":      2.5,
        "cost_out":     10.0,
        "context_k":    128,
        "free_tier":    False,
        "api_key_env":  "OPENROUTER_API_KEY",
        "strengths":    ["complex_reasoning", "math", "creative", "general"],
        "weaknesses":   ["cost"],
        "litellm_id":   "openrouter/openai/gpt-5.2",
        "openrouter_id":"openai/gpt-5.2",
    },

    "openrouter/openai/gpt-5.3-codex": {
        "display":      "GPT-5.3 Codex",
        "provider":     "openai",
        "tier":         1,
        "intelligence": 54,                          # #3 Intelligence Index
        "speed_tps":    60,
        "cost_in":      3.0,
        "cost_out":     15.0,
        "context_k":    200,
        "free_tier":    False,
        "api_key_env":  "OPENROUTER_API_KEY",
        "strengths":    ["coding", "terminal_tasks", "software_engineering", "swe_benchmark"],
        "weaknesses":   ["cost", "narrow_specialty"],
        "litellm_id":   "openrouter/openai/gpt-5.3-codex",
        "openrouter_id":"openai/gpt-5.3-codex",
    },

    # ══ TIER 2 – Alta qualità / Efficiente ════════════════════════════════════

    "openrouter/x-ai/grok-4": {
        "display":      "Grok 4",
        "provider":     "xai",
        "tier":         2,
        "intelligence": 50,
        "speed_tps":    100,
        "cost_in":      3.0,
        "cost_out":     15.0,
        "context_k":    128,
        "free_tier":    False,
        "api_key_env":  "OPENROUTER_API_KEY",
        "strengths":    ["real_time_search", "current_events", "multi_agent_native"],
        "weaknesses":   ["cost", "api_availability"],
        "litellm_id":   "openrouter/x-ai/grok-4",
        "openrouter_id":"x-ai/grok-4",
        "note":         "architettura multi-agent nativa (4 agent in parallelo)",
    },

    "openrouter/deepseek/deepseek-v3": {
        "display":      "DeepSeek V3",
        "provider":     "deepseek",
        "tier":         2,
        "intelligence": 48,
        "speed_tps":    60,
        "cost_in":      0.07,
        "cost_out":     0.28,
        "context_k":    64,
        "free_tier":    False,
        "api_key_env":  "OPENROUTER_API_KEY",
        "strengths":    ["cost_efficient", "coding", "math", "open_source_quality"],
        "weaknesses":   ["latency_not_optimized"],
        "litellm_id":   "openrouter/deepseek/deepseek-v3",
        "openrouter_id":"deepseek/deepseek-v3",
        "note":         "miglior rapporto qualità/prezzo assoluto 2026 ($0.07/1M)",
    },

    "openrouter/qwen/qwen3-max": {
        "display":      "Qwen3-Max",
        "provider":     "alibaba",
        "tier":         2,
        "intelligence": 47,
        "speed_tps":    55,
        "cost_in":      0.40,
        "cost_out":     1.20,
        "context_k":    32,
        "free_tier":    False,
        "api_key_env":  "OPENROUTER_API_KEY",
        "strengths":    ["cost_efficient", "multilingual", "open_source", "coding"],
        "weaknesses":   ["latency"],
        "litellm_id":   "openrouter/qwen/qwen3-max",
        "openrouter_id":"qwen/qwen3-max",
        "note":         "MoE 1T params, 92.3% AIME25, molto vicino ai modelli top",
    },

    "openrouter/mistralai/mistral-large": {
        "display":      "Mistral Large",
        "provider":     "mistral",
        "tier":         2,
        "intelligence": 44,
        "speed_tps":    120,
        "cost_in":      2.0,
        "cost_out":     6.0,
        "context_k":    128,
        "free_tier":    False,
        "api_key_env":  "OPENROUTER_API_KEY",
        "strengths":    ["speed", "multilingual", "europe_privacy"],
        "weaknesses":   ["reasoning_depth"],
        "litellm_id":   "openrouter/mistralai/mistral-large",
        "openrouter_id":"mistralai/mistral-large",
    },

    # ══ TIER 3 – Gratuito / Open-Source / Locale ══════════════════════════════

    "gemini/gemini-2.5-flash-lite": {
        "display":      "Gemini 2.5 Flash Lite",
        "provider":     "google",
        "tier":         3,
        "intelligence": 42,
        "speed_tps":    433,                         # #3 fastest model overall
        "cost_in":      0.01,
        "cost_out":     0.04,
        "context_k":    1000,
        "free_tier":    True,
        "rpm_free":     30,
        "rpd_free":     3000,
        "api_key_env":  "GOOGLE_API_KEY_2",
        "strengths":    ["ultra_fast", "cheap", "free", "high_volume"],
        "weaknesses":   ["quality"],
        "litellm_id":   "gemini/gemini-2.5-flash-lite",
    },

    "openrouter/google/gemma-3n-e4b": {
        "display":      "Gemma 3n E4B",
        "provider":     "google_open",
        "tier":         3,
        "intelligence": 36,
        "speed_tps":    400,
        "cost_in":      0.03,                        # cheapest model (artificialanalysis)
        "cost_out":     0.03,
        "context_k":    32,
        "free_tier":    False,
        "api_key_env":  "OPENROUTER_API_KEY",
        "strengths":    ["ultra_cheap", "fast", "simple_tasks"],
        "weaknesses":   ["quality", "reasoning"],
        "litellm_id":   "openrouter/google/gemma-3n-e4b",
        "openrouter_id":"google/gemma-3n-e4b",
        "note":         "modello più economico ($0.03/1M) su artificialanalysis",
    },

    "ollama/qwen3:8b": {
        "display":      "Qwen3 8B (locale)",
        "provider":     "ollama_local",
        "tier":         3,
        "intelligence": 35,
        "speed_tps":    30,
        "cost_in":      0.0,
        "cost_out":     0.0,
        "context_k":    32,
        "free_tier":    True,
        "rpm_free":     9999,
        "rpd_free":     999999,
        "api_key_env":  None,
        "strengths":    ["offline", "privacy", "no_rate_limit", "no_cost"],
        "weaknesses":   ["quality", "speed"],
        "litellm_id":   None,
        "note":         "fallback finale sempre disponibile",
    },
}

# ─── Routing table task-specifico (SkillOrchestra pattern) ───────────────────
# Ordine: migliore per task → cascade su fallimento

TASK_ROUTES = {
    # Coding e software engineering
    "coding": [
        "openrouter/anthropic/claude-sonnet-4-6",   # SWE-bench leader
        "openrouter/openai/gpt-5.3-codex",          # specialist coding
        "gemini/gemini-3.1-pro",                    # ottimo su coding
        "openrouter/deepseek/deepseek-v3",          # cost-efficient
        "gemini/gemini-2.5-flash",                  # free fallback
        "ollama/qwen3:8b",                          # locale finale
    ],
    # Ragionamento complesso e analisi
    "reasoning": [
        "gemini/gemini-3.1-pro",                    # #1 Intelligence Index
        "openrouter/openai/gpt-5.2",
        "openrouter/anthropic/claude-opus-4-6",
        "openrouter/anthropic/claude-sonnet-4-6",
        "gemini/gemini-2.5-flash",
        "ollama/qwen3:8b",
    ],
    # Matematica e STEM
    "math": [
        "gemini/gemini-3.1-pro",                    # 77.1% ARC-AGI-2
        "openrouter/openai/gpt-5.2",
        "openrouter/deepseek/deepseek-v3",          # forte in math
        "openrouter/qwen/qwen3-max",                # 92.3% AIME25
        "gemini/gemini-2.5-flash",
        "ollama/qwen3:8b",
    ],
    # Ricerca e notizie in tempo reale
    "search": [
        "openrouter/x-ai/grok-4",                  # real-time search nativo
        "gemini/gemini-2.5-flash",
        "openrouter/openai/gpt-5.2",
        "ollama/qwen3:8b",
    ],
    # Visione e screenshot
    "vision": [
        "gemini/gemini-2.5-flash",                  # visione ottima + free
        "gemini/gemini-3.1-pro",
        "openrouter/openai/gpt-5.2",
    ],
    # Compiti veloci e economici
    "fast": [
        "gemini/gemini-2.5-flash-lite",             # 433 t/s, free
        "gemini/gemini-2.5-flash",
        "openrouter/google/gemma-3n-e4b",           # $0.03/1M
        "ollama/qwen3:8b",
    ],
    # Solo gratuito
    "free_only": [
        "gemini/gemini-2.5-flash",
        "gemini/gemini-2.5-flash-lite",
        "ollama/qwen3:8b",
    ],
    # Testo creativo
    "creative": [
        "openrouter/openai/gpt-5.2",
        "openrouter/anthropic/claude-sonnet-4-6",
        "openrouter/x-ai/grok-4",
        "gemini/gemini-2.5-flash",
        "ollama/qwen3:8b",
    ],
    # Generico
    "general": [
        "gemini/gemini-2.5-flash",
        "openrouter/anthropic/claude-sonnet-4-6",
        "openrouter/deepseek/deepseek-v3",
        "gemini/gemini-3.1-pro",
        "ollama/qwen3:8b",
    ],
    # Multi-agent parallelo (fan-out 3 modelli)
    "parallel_top3": [
        "gemini/gemini-3.1-pro",
        "openrouter/anthropic/claude-sonnet-4-6",
        "openrouter/openai/gpt-5.2",
    ],
}

# ─── Keyword → task_type (classificazione automatica) ────────────────────────
TASK_KEYWORDS = {
    "coding":    ["codice","python","bug","funzione","script","def ","class ",
                  "import","refactor","debug","errore","syntax","code","fix",
                  "github","commit","patch","modulo","file .py"],
    "reasoning": ["perché","analizza","spiega","ragiona","deduce","why","explain",
                  "analyze","reason","logic","strategia","piano","valuta"],
    "math":      ["calcola","equazione","matematica","formula","integrale",
                  "calculate","equation","math","compute","numero","algebra"],
    "search":    ["cerca","ricerca","notizie","aggiornamento","oggi","attuale",
                  "search","news","current","latest","2026","internet","online"],
    "vision":    ["screenshot","immagine","schermo","vedi","guarda",
                  "image","visual","foto","picture","screen"],
    "creative":  ["scrivi","crea","storia","poesia","write","create",
                  "story","creative","testo","articolo","blog"],
    "fast":      ["veloce","rapido","breve","quick","short","semplice","simple"],
}


class AIRouter:
    """
    Router intelligente: sceglie il modello ottimale per ogni task.
    Basato su SkillOrchestra (2026) e SMoA (Sparse Mixture of Agents).
    """

    def __init__(self, config):
        self.config      = config
        self._usage_file = config.get_memory_dir() / "router_usage.json"
        self._usage      = self._load_usage()
        self._cooldown   = {}   # model_id → timestamp fine cooldown

    # ─── Classificazione task ─────────────────────────────────────────────────

    def classify(self, prompt: str) -> str:
        """Classifica il tipo di task dalle keyword nel prompt."""
        p = prompt.lower()
        scores = {t: sum(1 for k in kws if k in p)
                  for t, kws in TASK_KEYWORDS.items()}
        best_task  = max(scores, key=scores.get)
        best_score = scores[best_task]
        result     = best_task if best_score > 0 else "general"
        log.debug("Classify: '" + prompt[:60] + "' → " + result +
                  " (score=" + str(best_score) + ")")
        return result

    # ─── Scelta modello ───────────────────────────────────────────────────────

    def get_route(self, task_type: str = "general",
                  mode: str = "best") -> list:
        """
        Ritorna lista ordinata di model_id da provare.
        mode:
          best      → solo il top per task_type
          cascade   → lista completa, prova in ordine
          parallel  → top-3 per esecuzione parallela
          free_only → solo modelli gratuiti
        """
        if mode == "parallel":
            candidates = TASK_ROUTES.get("parallel_top3", [])
        elif mode == "free_only":
            candidates = TASK_ROUTES["free_only"]
        else:
            candidates = TASK_ROUTES.get(task_type, TASK_ROUTES["general"])

        # Filtra modelli disponibili (API key presente) e non in cooldown
        available = [m for m in candidates
                     if self._is_available(m)]

        if not available:
            # Fallback assoluto: Ollama locale
            log.warning("Nessun modello disponibile → Ollama fallback")
            return ["ollama/qwen3:8b"]

        return available if mode != "best" else [available[0]]

    def best_model(self, prompt: str, force_free: bool = False) -> str:
        """Ritorna il singolo modello migliore per il prompt dato."""
        task_type = self.classify(prompt)
        mode      = "free_only" if force_free else "best"
        route     = self.get_route(task_type, mode)
        return route[0]

    # ─── Disponibilità modello ────────────────────────────────────────────────

    def _is_available(self, model_id: str) -> bool:
        # Controlla cooldown (dopo 429)
        if model_id in self._cooldown:
            if time.time() < self._cooldown[model_id]:
                return False
            else:
                del self._cooldown[model_id]

        meta    = MODELS_2026.get(model_id, {})
        key_env = meta.get("api_key_env")

        # Locale: sempre disponibile
        if not key_env:
            return True

        return bool(os.environ.get(key_env, "").strip())

    def set_cooldown(self, model_id: str, seconds: int = 65):
        """Mette un modello in cooldown (usato dopo 429)."""
        self._cooldown[model_id] = time.time() + seconds
        log.info("Cooldown " + model_id + " per " + str(seconds) + "s")

    def available_models(self) -> list:
        """Lista di tutti i modelli con API key configurata."""
        return [m for m in MODELS_2026 if self._is_available(m)]

    def get_model_info(self, model_id: str) -> dict:
        return MODELS_2026.get(model_id, {})

    # ─── Usage tracking ──────────────────────────────────────────────────────

    def record(self, model_id: str, task_type: str,
               success: bool, latency_s: float = 0.0):
        from datetime import datetime
        month = datetime.now().strftime("%Y-%m")
        key   = model_id + "|" + task_type
        self._usage.setdefault(month, {}).setdefault(key, {
            "calls": 0, "ok": 0, "fail": 0, "avg_latency": 0.0
        })
        rec = self._usage[month][key]
        rec["calls"] += 1
        if success:
            rec["ok"] += 1
            # media mobile latenza
            rec["avg_latency"] = (rec["avg_latency"] * (rec["ok"] - 1) +
                                  latency_s) / rec["ok"]
        else:
            rec["fail"] += 1
        self._save_usage()

    def stats_report(self) -> str:
        """Report testuale statistiche di routing."""
        from datetime import datetime
        month = datetime.now().strftime("%Y-%m")
        data  = self._usage.get(month, {})
        lines = ["=== AIRouter Stats " + month + " ===",
                 "Modelli disponibili: " + str(len(self.available_models())),
                 ""]
        for key, rec in sorted(data.items(),
                                key=lambda x: x[1]["calls"], reverse=True)[:10]:
            model, task = key.split("|", 1)
            name        = MODELS_2026.get(model, {}).get("display", model)
            rate        = round(rec["ok"] / max(rec["calls"], 1) * 100)
            lat         = round(rec["avg_latency"], 1)
            lines.append(f"  {name:<30} {task:<12} "
                         f"{rec['calls']:>4} calls "
                         f"{rate:>3}% ok "
                         f"{lat:>5}s avg")
        lines += ["", "Modelli mancanti (aggiungi chiavi in .env):"]
        for m, meta in MODELS_2026.items():
            env = meta.get("api_key_env")
            if env and not os.environ.get(env, "").strip():
                lines.append("  ✗ " + meta["display"] + " → " + env)
        return "\n".join(lines)

    def _load_usage(self) -> dict:
        if self._usage_file.exists():
            try:
                return json.loads(self._usage_file.read_text(encoding="utf-8"))
            except Exception:
                pass
        return {}

    def _save_usage(self):
        try:
            self._usage_file.write_text(
                json.dumps(self._usage, indent=2, ensure_ascii=False),
                encoding="utf-8"
            )
        except Exception:
            pass
