# DUST AI – Orchestra v2.0
## Guida Completa al Sistema Multi-AI

---

## Cos'è e da dove viene

Questo sistema è basato su ricerca approfondita dei pattern più avanzati del 2026:

| Pattern | Fonte | Cosa implementa |
|---|---|---|
| **SkillOrchestra** | Paper Mar 2026 | Routing skill-aware: ogni task → modello specializzato |
| **SMoA** | Paper 2025 | Sparse Mixture of Agents: non tutti i modelli per tutto |
| **ReConcile** | ACL 2024 | Round-table consensus tra modelli diversi |
| **Fan-out/Fan-in** | Google ADK | Esecuzione parallela + sintesi |
| **SALLMA** | Arxiv 2025 | Orchestrazione cloud-to-edge |
| **A2A Protocol** | AgentScope 2026 | Agent-to-agent chaining |
| **Circuit Breaker** | Enterprise 2026 | Rate limit automatico con cooldown |

---

## Architettura

```
DUST GUI / process_queue
        │
        ▼
  AIConductor          ← punto di ingresso unico
  ┌─────────┐
  │ ask()   │
  └────┬────┘
       │
  ┌────▼──────────────────────────────┐
  │  AIRouter (classifica task)       │
  │  coding → Claude + Codex          │
  │  reasoning → Gemini3 + GPT-5.2   │
  │  math → Gemini3 + DeepSeek       │
  │  search → Grok (real-time)       │
  │  free_only → Gemini Flash Lite   │
  └────┬──────────────────────────────┘
       │
  ┌────▼──────────────────────────────┐
  │  AIGateway (esegue le chiamate)  │
  │  1. LiteLLM SDK (100+ provider)  │
  │  2. Gemini diretto (fallback)    │
  │  3. OpenRouter diretto           │
  │  4. Ollama locale (finale)       │
  └────┬──────────────────────────────┘
       │
  ┌────▼──────────────────────────────┐
  │  AIParallel (opzionale)          │
  │  Fan-out → N modelli in //        │
  │  Consensus/Synthesis             │
  └───────────────────────────────────┘
       │
  GitHubSync (auto-commit ogni task)
  github.com/Tenkulo/dustai
```

---

## Modelli disponibili (Marzo 2026)

### Benchmark Intelligence Index (ArtificialAnalysis.ai, Mar 2026)

| Rank | Modello | Score | Punto di forza |
|---|---|---|---|
| 🥇 1 | Gemini 3.1 Pro | 57 | Benchmark leader, 77% ARC-AGI-2 |
| 🥇 1 | GPT-5.4 | 57 | Reasoning + math |
| 🥈 3 | GPT-5.3 Codex | 54 | Software engineering |
| 🥉 4 | Claude Opus 4.6 | 53 | Analisi lunga |
| 4 | Claude Sonnet 4.6 | 52 | Coding, SWE-bench leader |
| 5 | DeepSeek V3 | 48 | Miglior prezzo ($0.07/1M) |
| 6 | Qwen3-Max | 47 | Open-source vicino al top |
| – | Gemini 2.5 Flash | 49 | Gratuito + veloce + 1M contesto |

### Come DUST sceglie automaticamente

```
Task "fix questo bug in python"
  → classify() → "coding"
  → route() → [Claude Sonnet 4.6, GPT-5.3 Codex, Gemini 3.1 Pro, ...]
  → gateway.call(Claude Sonnet) → OK ✅
  
Task "calcola l'integrale di..."
  → classify() → "math"  
  → route() → [Gemini 3.1 Pro, GPT-5.2, DeepSeek V3, ...]
  → se 429 → cooldown 65s → prova prossimo → OK ✅

Task "ultime notizie su..."
  → classify() → "search"
  → route() → [Grok 4 (real-time search nativo)]
  → OK ✅
```

---

## Modalità di utilizzo

### 1. Singolo modello (best for task)
```
# Nella GUI DUST:
ai_ask prompt="refactora questa funzione" model=auto
ai_ask prompt="spiega il teorema di Bayes" model=gemini3
ai_ask prompt="scrivi un haiku" model=gpt
ai_ask prompt="debug veloce" model=free   ← solo modelli gratuiti
```

### 2. Parallelo (consensus su 3 modelli)
```
ai_parallel prompt="qual è la soluzione migliore a questo problema?"
ai_parallel prompt="review di questo codice" models="claude,gpt,gemini3"
```

### 3. Cascade (prova in ordine)
```
ai_ask prompt="analisi strategica" model=auto mode=cascade
```

### 4. Lista modelli disponibili
```
ai_models filter_available=available    ← solo con API key
ai_models filter_available=free         ← solo gratuiti
ai_models filter_available=all          ← tutti (con ✅/❌)
```

---

## GitHub Sync

DUST è sempre allineato con `github.com/Tenkulo/dustai`:

```
# Sync manuale
git_sync message="update configurazione"

# Commit specifico
git_commit message="aggiunto nuovo modello"

# Solo push
git_push

# Stato repo
git_status
```

**Auto-sync**: DUST committa automaticamente dopo ogni ciclo di self-improvement (ogni 10 task).

---

## Setup chiavi API

Aggiungi in `A:\dustai_stuff\.env`:

```env
# OpenRouter – 500+ modelli con un'unica chiave
# Gratuito fino a $10/mese (piano free tier)
# Registrazione: openrouter.ai
OPENROUTER_API_KEY=sk-or-v1-...

# Google Gemini – crea 3 progetti su aistudio.google.com
# Ogni progetto = 1500 req/giorno GRATIS su Flash
GOOGLE_API_KEY=AIza...          # progetto 1
GOOGLE_API_KEY_2=AIza...        # progetto 2
GOOGLE_API_KEY_3=AIza...        # progetto 3 (per Gemini 3.1 Pro)
```

Con **solo Google** (3 chiavi gratuite) ottieni:
- 4500 req/giorno su Gemini Flash (task veloci)
- 150 req/giorno su Gemini 3.1 Pro (task complessi)
- Modello locale Ollama sempre disponibile

Con **OpenRouter** ($5-10/mese) aggiungi:
- Claude Sonnet 4.6 (coding leader)
- GPT-5.2 / GPT-5.3 Codex
- DeepSeek V3 ($0.07/1M – ultra economico)
- Grok 4 (real-time search)
- Qwen3-Max (open-source top)
- 490+ altri modelli

---

## File nel sistema

```
A:\dustai\src\
├── ai_router.py       ← routing intelligente (catalog Mar 2026)
├── ai_gateway.py      ← layer chiamate (LiteLLM + OpenRouter + Gemini + Ollama)
├── ai_parallel.py     ← fan-out parallelo + consensus
├── ai_conductor.py    ← orchestratore centrale
├── github_sync.py     ← allineamento GitHub/Tenkulo/dustai
└── tools\
    └── registry.py    ← tool ai_ask, ai_parallel, git_sync, ...
```

```
A:\dustai_stuff\
├── .env               ← API keys (OPENROUTER, GOOGLE x3)
├── memory\
│   ├── router_usage.json     ← statistiche per modello
│   └── conductor_state.json  ← contatore task
├── ai_responses\      ← ogni risposta salvata (JSON)
└── logs\
    └── gateway_usage.jsonl   ← log JSONL per analisi
```

---

## Ricerca e fonti

**Fonti principali usate per questa implementazione:**

- [ArtificialAnalysis.ai](https://artificialanalysis.ai/leaderboards/models) – Intelligence Index Mar 2026
- [LMCouncil.ai](https://lmcouncil.ai/benchmarks) – benchmark comparativi
- [DesignForOnline.com](https://designforonline.com/the-best-ai-models-so-far-in-2026/) – guida modelli 2026
- [VirtusLab.com](https://virtuslab.com/blog/ai/best-gen-ai-beginning-2026) – best models Jan 2026
- [awesome-multi-agent-papers](https://github.com/kyegomez/awesome-multi-agent-papers) – paper multi-agent
- [awesome-llm-agents](https://github.com/kaushikb11/awesome-llm-agents) – framework survey Mar 2026
- [SALLMA paper](https://robertoverdecchia.github.io/papers/SATrends_2025.pdf) – architettura cloud-to-edge
- [LiteLLM vs OpenRouter](https://xenoss.io/blog/openrouter-vs-litellm) – comparativo gateway
- [Bifrost/LiteLLM alternatives 2026](https://www.getmaxim.ai/articles/top-5-litellm-alternatives-in-2026/)

**Key insight dalla ricerca:**
- LiteLLM (SDK open-source) è la scelta ottimale per DUST: zero markup, Python-nativo, 100+ provider
- OpenRouter come backend di LiteLLM = accesso a 500+ modelli con una chiave
- Gemini 3.1 Pro è il modello con Intelligence Index più alto a Mar 2026 (score 57, pari a GPT-5.4)
- Claude Sonnet 4.6 è il leader SWE-bench per coding
- DeepSeek V3 è il miglior rapporto qualità/prezzo ($0.07/1M input)
- Grok 4 ha architettura multi-agent nativa (4 agent in parallelo internamente)
- Circuit breaker pattern + cooldown 65s = zero blocchi su rate limit
