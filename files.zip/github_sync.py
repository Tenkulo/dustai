"""
DUST AI – GitHubSync v2.0
Sistema di allineamento con github.com/Tenkulo/dustai.

Funzioni:
  1. AUTO-COMMIT  — commit automatico di ogni modifica su A:\\dustai
  2. AUTO-PUSH    — push periodico verso master
  3. AUTO-PULL    — sincronizzazione entrante da GitHub
  4. DIFF-WATCH   — rileva file modificati e li include nel commit
  5. BACKUP       — backup automatico su A:\\dustai_stuff\\backups prima di ogni push
  6. STATUS       — stato completo repo + diff pending

Integrazione in DUST:
  - Chiamato dal heartbeat ogni 30 min (auto-push)
  - Chiamato dopo ogni self_improvement_loop (auto-commit con note)
  - Esposto come tool: git_sync, git_commit, git_status
"""

import subprocess
import logging
import json
import shutil
import time
from pathlib import Path
from datetime import datetime

log = logging.getLogger("GitHubSync")

REPO_PATH  = Path(r"A:\dustai")
BACKUP_DIR = Path(r"A:\dustai_stuff\backups")
REMOTE     = "origin"
BRANCH     = "master"

# File da escludere dai commit automatici
GITIGNORE_AUTO = [
    "*.pyc", "__pycache__", ".env",
    "*.log", "*.bak_*",
]


class GitHubSync:
    """
    Gestisce sincronizzazione bidirezionale con github.com/Tenkulo/dustai.
    """

    def __init__(self, config):
        self.config   = config
        self.repo_dir = REPO_PATH
        self._last_push = 0.0
        self._push_interval = 30 * 60   # 30 minuti tra push automatici

    # ─── API pubblica ─────────────────────────────────────────────────────────

    def auto_sync(self, commit_msg: str = "") -> dict:
        """
        Sincronizzazione completa:
        1. Pull (aggiornamenti da GitHub)
        2. Commit (modifiche locali)
        3. Push (invia a GitHub)
        """
        results = {}

        # 1. Pull
        pull = self.pull()
        results["pull"] = pull

        # 2. Commit se ci sono modifiche
        has_changes = self.has_uncommitted_changes()
        if has_changes:
            msg    = commit_msg or self._auto_commit_message()
            commit = self.commit(msg)
            results["commit"] = commit
        else:
            results["commit"] = {"ok": True, "msg": "Nessuna modifica da committare"}

        # 3. Push (rispetta intervallo)
        if time.time() - self._last_push > self._push_interval or commit_msg:
            push             = self.push()
            results["push"]  = push
            if push.get("ok"):
                self._last_push = time.time()
        else:
            wait = int((self._push_interval - (time.time() - self._last_push)) / 60)
            results["push"] = {"ok": True, "msg": "Prossimo push tra " + str(wait) + " min"}

        return results

    def commit(self, message: str, files: list = None) -> dict:
        """
        Commit delle modifiche correnti.
        files: lista specifica di file, None = tutti
        """
        try:
            # Stage
            if files:
                for f in files:
                    self._run(["git", "add", str(f)])
            else:
                self._run(["git", "add", "-A"])

            # Verifica che ci sia qualcosa da committare
            status = self._run(["git", "status", "--porcelain"])
            if not status.get("stdout", "").strip():
                return {"ok": True, "msg": "Niente da committare"}

            # Commit con timestamp
            ts      = datetime.now().strftime("%Y-%m-%d %H:%M")
            full_msg = "[DUST " + ts + "] " + message

            result  = self._run(["git", "commit", "-m", full_msg])
            if result.get("ok"):
                log.info("Commit OK: " + full_msg)
                return {"ok": True, "msg": full_msg, "hash": self._last_commit_hash()}
            return {"ok": False, "error": result.get("stderr", "errore commit")}

        except Exception as e:
            return {"ok": False, "error": str(e)}

    def push(self) -> dict:
        """Push verso GitHub."""
        try:
            # Backup prima del push
            self._backup()

            result = self._run(["git", "push", REMOTE, BRANCH])
            if result.get("ok"):
                log.info("Push OK → github.com/Tenkulo/dustai")
                return {"ok": True, "msg": "Push completato → github.com/Tenkulo/dustai"}

            # Prova con force se divergenti (safe: solo dopo backup)
            if "non-fast-forward" in result.get("stderr", ""):
                log.warning("Push rifiutato (non-fast-forward) → force push")
                result2 = self._run(["git", "push", "--force-with-lease",
                                     REMOTE, BRANCH])
                if result2.get("ok"):
                    return {"ok": True, "msg": "Force push completato"}
                return {"ok": False, "error": result2.get("stderr", "")}

            return {"ok": False, "error": result.get("stderr", "errore push")}

        except Exception as e:
            return {"ok": False, "error": str(e)}

    def pull(self) -> dict:
        """Pull da GitHub (aggiornamenti in arrivo)."""
        try:
            result = self._run(["git", "pull", REMOTE, BRANCH, "--rebase"])
            if result.get("ok"):
                stdout = result.get("stdout", "")
                if "Already up to date" in stdout or "Aggiornato" in stdout:
                    return {"ok": True, "msg": "Repo già aggiornato"}
                return {"ok": True, "msg": "Pull completato:\n" + stdout[:300]}
            return {"ok": False, "error": result.get("stderr", "")}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def status(self) -> str:
        """Report completo stato repo."""
        lines = ["=== GitHub Sync Status ===",
                 "Repo: " + str(self.repo_dir),
                 "Remote: github.com/Tenkulo/dustai",
                 ""]

        # Branch corrente
        branch = self._run(["git", "branch", "--show-current"])
        lines.append("Branch: " + branch.get("stdout", "?").strip())

        # Ultimo commit
        last = self._run(["git", "log", "--oneline", "-3"])
        lines.append("Ultimi commit:\n" + last.get("stdout", "?").strip())

        # Modifiche pending
        dirty = self._run(["git", "status", "--short"])
        dirty_out = dirty.get("stdout", "").strip()
        if dirty_out:
            lines.append("\nModifiche non committate:")
            lines.append(dirty_out[:500])
        else:
            lines.append("\nWorking tree pulito ✅")

        # Diff con remote
        lines.append("")
        ahead_behind = self._run(
            ["git", "rev-list", "--count", "--left-right",
             BRANCH + "...origin/" + BRANCH]
        )
        ab = ahead_behind.get("stdout", "").strip()
        if ab:
            parts = ab.split("\t")
            if len(parts) == 2:
                lines.append("Ahead: " + parts[0] + " commit | Behind: " + parts[1] + " commit")

        return "\n".join(lines)

    def has_uncommitted_changes(self) -> bool:
        result = self._run(["git", "status", "--porcelain"])
        return bool(result.get("stdout", "").strip())

    # ─── Auto-commit intelligence ─────────────────────────────────────────────

    def _auto_commit_message(self) -> str:
        """
        Genera messaggio di commit automatico analizzando i file modificati.
        """
        result  = self._run(["git", "status", "--short"])
        changes = result.get("stdout", "").strip().splitlines()

        if not changes:
            return "auto: sync"

        # Categorie di modifiche
        new_files     = [l[3:] for l in changes if l.startswith("?? ")]
        modified      = [l[3:] for l in changes if l.startswith(" M ") or l.startswith("M ")]
        deleted       = [l[3:] for l in changes if l.startswith(" D ") or l.startswith("D ")]

        parts = []
        if modified:
            parts.append("edit: " + ", ".join(modified[:3]))
        if new_files:
            parts.append("add: " + ", ".join(new_files[:3]))
        if deleted:
            parts.append("del: " + ", ".join(deleted[:2]))

        msg = " | ".join(parts) if parts else "auto: modifiche varie"
        # Tronca a 72 char (limite git buone pratiche)
        return msg[:72]

    def _last_commit_hash(self) -> str:
        result = self._run(["git", "rev-parse", "--short", "HEAD"])
        return result.get("stdout", "").strip()

    # ─── Backup ───────────────────────────────────────────────────────────────

    def _backup(self):
        """Backup del repo prima di ogni push."""
        try:
            BACKUP_DIR.mkdir(parents=True, exist_ok=True)
            ts      = datetime.now().strftime("%Y%m%d_%H%M%S")
            dst     = BACKUP_DIR / ("dustai_" + ts)
            shutil.copytree(
                self.repo_dir, dst,
                ignore=shutil.ignore_patterns(
                    ".git", "__pycache__", "*.pyc", "node_modules"
                ),
            )
            # Mantieni solo gli ultimi 5 backup
            backups = sorted(BACKUP_DIR.glob("dustai_*"))
            for old in backups[:-5]:
                shutil.rmtree(old, ignore_errors=True)
            log.debug("Backup: " + str(dst))
        except Exception as e:
            log.warning("Backup fallito: " + str(e))

    # ─── subprocess wrapper ───────────────────────────────────────────────────

    def _run(self, cmd: list) -> dict:
        try:
            result = subprocess.run(
                cmd,
                cwd=str(self.repo_dir),
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=60,
            )
            return {
                "ok":     result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "code":   result.returncode,
            }
        except subprocess.TimeoutExpired:
            return {"ok": False, "error": "Timeout git command", "stdout": "", "stderr": ""}
        except Exception as e:
            return {"ok": False, "error": str(e), "stdout": "", "stderr": ""}


# ─── Tool wrapper per ToolRegistry ───────────────────────────────────────────

class GitSyncTool:
    """Espone GitHubSync come tool standard di DUST."""

    def __init__(self, config):
        self.config = config
        self._sync  = None

    def _get(self) -> GitHubSync:
        if not self._sync:
            self._sync = GitHubSync(self.config)
        return self._sync

    def git_sync(self, message: str = "") -> str:
        """Sincronizzazione completa: pull + commit + push."""
        results = self._get().auto_sync(message)
        lines   = []
        for step, res in results.items():
            icon = "✅" if res.get("ok") else "❌"
            lines.append(icon + " " + step + ": " + res.get("msg", res.get("error", "")))
        return "\n".join(lines)

    def git_commit(self, message: str) -> str:
        """Commit delle modifiche correnti."""
        result = self._get().commit(message)
        if result.get("ok"):
            return "✅ Commit: " + result.get("msg", "")
        return "❌ " + result.get("error", "errore")

    def git_push(self) -> str:
        """Push verso GitHub."""
        result = self._get().push()
        return ("✅ " if result.get("ok") else "❌ ") + result.get("msg", result.get("error", ""))

    def git_pull(self) -> str:
        """Pull da GitHub."""
        result = self._get().pull()
        return ("✅ " if result.get("ok") else "❌ ") + result.get("msg", result.get("error", ""))

    def git_status(self) -> str:
        """Stato completo repo."""
        return self._get().status()
