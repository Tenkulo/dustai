"""
DUST AI – AIConductor v2.0
Il cervello centrale che orchestra tutto.

AIConductor è il punto d'ingresso unico per tutte le operazioni AI di DUST.
Decide autonomamente:
  - Quale modello usare (AIRouter)
  - Se eseguire in parallelo o in cascade (AIParallel)
  - Come gestire i fallback (AIGateway)
  - Quando sincronizzare con GitHub (GitHubSync)
  - Come salvare e riutilizzare la conoscenza (memoria + A:\dustai_stuff)

Pattern architetturali implementati (da ricerca 2026):
  - SALLMA Operational Layer (cloud-to-edge continuum)
  - SkillOrchestra hierarchical routing
  - AgentScope A2A (Agent-to-Agent) chaining
  - Circuit breaker per rate limit (pattern enterprise 2026)
  - SMoA: Sparse Mixture of Agents (non tutti i modelli per tutti i task)
"""

import logging
import time
import json
from pathlib import Path
from datetime import datetime
from typing import Optional

log = logging.getLogger("AIConductor")


class AIConductor:
    """
    Orchestratore centrale DUST.
    Unico punto di accesso per tutte le query AI.
    """

    def __init__(self, config):
        self.config  = config
        self._memory = config.get_base_path() / "memory"
        self._memory.mkdir(exist_ok=True)

        # Lazy init dei componenti
        self._gateway  = None
        self._parallel = None
        self._git_sync = None
        self._browser  = None

        # Contatore task (per self-improvement trigger)
        self._task_count = self._load_task_count()

    # ─── Gateway e componenti (lazy) ─────────────────────────────────────────

    def _gw(self):
        if not self._gateway:
            from .ai_gateway import AIGateway
            self._gateway = AIGateway(self.config)
        return self._gateway

    def _par(self):
        if not self._parallel:
            from .ai_parallel import AIParallel
            self._parallel = AIParallel(self.config, self._gw())
        return self._parallel

    def _git(self):
        if not self._git_sync:
            from .github_sync import GitHubSync
            self._git_sync = GitHubSync(self.config)
        return self._git_sync

    # ─── API pubblica ──────────────────────────────────────────────────────────

    def ask(self, prompt: str,
            mode:      str = "auto",
            model:     str = "auto",
            parallel:  bool = False,
            task_type: str = "auto",
            context:   str = "") -> dict:
        """
        Query principale di DUST.

        Args:
          prompt:    testo della richiesta
          mode:      auto | best | cascade | free_only
          model:     auto | nome-modello-specifico
          parallel:  True = fan-out su top-3 modelli
          task_type: auto | coding | reasoning | math | search | vision | creative
          context:   contesto aggiuntivo (es. contenuto file)

        Returns:
          {"ok": bool, "text": str, "model": str, "meta": dict}
        """
        start = time.time()

        # Prepara prompt con contesto
        full_prompt = prompt
        if context:
            full_prompt = (
                "CONTESTO:\n" + context[:4000] + "\n\n"
                "RICHIESTA:\n" + prompt
            )

        # ── Modalità parallela ────────────────────────────────────────────────
        if parallel:
            result = self._ask_parallel(full_prompt, task_type)

        # ── Modello specifico richiesto ───────────────────────────────────────
        elif model != "auto":
            result = self._ask_specific(full_prompt, model)

        # ── Routing automatico (default) ─────────────────────────────────────
        else:
            result = self._ask_auto(full_prompt, task_type, mode)

        # Aggiunge metadati
        result["latency_total_s"] = round(time.time() - start, 2)
        result["ts"]              = datetime.now().isoformat()

        # Incrementa contatore e trigger self-improvement ogni 10 task
        self._task_count += 1
        self._save_task_count()
        if self._task_count % 10 == 0:
            self._trigger_self_improvement()

        return result

    def ask_parallel(self, prompt: str,
                     models: list = None,
                     task_type: str = "auto") -> dict:
        """Fan-out esplicito su lista modelli."""
        return self._ask_parallel(prompt, task_type, models)

    # ─── Routing interno ──────────────────────────────────────────────────────

    def _ask_auto(self, prompt: str, task_type: str, mode: str) -> dict:
        """Routing automatico via AIGateway."""
        result = self._gw().call_auto(prompt, task_type, mode)
        return self._normalize(result)

    def _ask_specific(self, prompt: str, model_id: str) -> dict:
        """Chiama modello specifico."""
        # Gestisce alias brevi
        ALIASES = {
            "gemini":       "gemini/gemini-2.5-flash",
            "gemini_pro":   "gemini/gemini-3.1-pro",
            "gemini3":      "gemini/gemini-3.1-pro",
            "claude":       "openrouter/anthropic/claude-sonnet-4-6",
            "claude_opus":  "openrouter/anthropic/claude-opus-4-6",
            "gpt":          "openrouter/openai/gpt-5.2",
            "codex":        "openrouter/openai/gpt-5.3-codex",
            "grok":         "openrouter/x-ai/grok-4",
            "deepseek":     "openrouter/deepseek/deepseek-v3",
            "qwen":         "openrouter/qwen/qwen3-max",
            "mistral":      "openrouter/mistralai/mistral-large",
            "ollama":       "ollama/qwen3:8b",
            "free":         "gemini/gemini-2.5-flash",
        }
        resolved = ALIASES.get(model_id.lower(), model_id)
        result   = self._gw().call(resolved, prompt)
        return self._normalize(result)

    def _ask_parallel(self, prompt: str, task_type: str,
                      models: list = None) -> dict:
        """Fan-out parallelo con consensus."""
        gw = self._gw()

        if not models:
            # Usa top-3 modelli disponibili per task_type
            router  = gw.router
            if task_type == "auto":
                task_type = router.classify(prompt)
            models  = router.get_route(task_type, "cascade")[:3]

        if len(models) < 2:
            # Solo 1 modello disponibile → normale
            return self._ask_auto(prompt, task_type, "best")

        result = self._par().run(prompt, models, timeout=45)
        return self._normalize(result)

    def _normalize(self, result: dict) -> dict:
        """Normalizza il formato di ritorno."""
        if result.get("ok"):
            return {
                "ok":    True,
                "text":  result.get("text", ""),
                "model": result.get("model_id", result.get("model", "?")),
                "meta":  {k: v for k, v in result.items()
                          if k not in ("ok", "text", "model_id", "model")},
            }
        return {
            "ok":    False,
            "text":  "",
            "error": result.get("error", "errore sconosciuto"),
            "model": result.get("model_id", "?"),
            "meta":  {},
        }

    # ─── Self-improvement trigger ─────────────────────────────────────────────

    def _trigger_self_improvement(self):
        """Avvia self-improvement loop ogni 10 task (asincrono)."""
        try:
            import threading
            def run():
                try:
                    from .agents.self_improvement_loop import SelfImprovementLoop
                    sil = SelfImprovementLoop(self.config)
                    sil.run_cycle()
                    # Dopo ogni ciclo, sync con GitHub
                    self._git().commit(
                        "self-improvement: ciclo " + str(self._task_count // 10)
                    )
                except Exception as e:
                    log.warning("Self-improvement: " + str(e))
            threading.Thread(target=run, daemon=True).start()
        except Exception:
            pass

    # ─── GitHub sync ──────────────────────────────────────────────────────────

    def sync_github(self, message: str = "") -> str:
        """Sincronizzazione manuale con GitHub."""
        try:
            results = self._git().auto_sync(message)
            out = []
            for step, res in results.items():
                icon = "✅" if res.get("ok") else "❌"
                out.append(icon + " " + step + ": " +
                           res.get("msg", res.get("error", "")))
            return "\n".join(out)
        except Exception as e:
            return "❌ GitHub sync: " + str(e)

    # ─── Status ───────────────────────────────────────────────────────────────

    def status(self) -> str:
        """Report completo stato dell'orchestra."""
        lines = [
            "╔══════════════════════════════════════╗",
            "║  DUST AI – AIConductor Status        ║",
            "╚══════════════════════════════════════╝",
            "",
            "Task eseguiti: " + str(self._task_count),
        ]
        try:
            lines.append(self._gw().status_report())
        except Exception:
            lines.append("Gateway: non inizializzato")
        try:
            lines.append(self._git().status())
        except Exception:
            lines.append("GitHub: non inizializzato")
        return "\n".join(lines)

    # ─── Contatore task ───────────────────────────────────────────────────────

    def _load_task_count(self) -> int:
        f = self._memory / "conductor_state.json"
        if f.exists():
            try:
                return json.loads(f.read_text(encoding="utf-8")).get("task_count", 0)
            except Exception:
                pass
        return 0

    def _save_task_count(self):
        f = self._memory / "conductor_state.json"
        try:
            f.write_text(json.dumps({"task_count": self._task_count},
                                    indent=2, ensure_ascii=False),
                         encoding="utf-8")
        except Exception:
            pass


# ─── Tool wrapper per ToolRegistry ───────────────────────────────────────────

class AIConductorTool:
    """Espone AIConductor come tool standard di DUST."""

    def __init__(self, config):
        self.config     = config
        self._conductor = None

    def _get(self) -> AIConductor:
        if not self._conductor:
            self._conductor = AIConductor(self.config)
        return self._conductor

    # ── Tool: ai_ask ──────────────────────────────────────────────────────────
    def ai_ask(self, prompt: str, model: str = "auto",
               mode: str = "auto") -> str:
        """
        Interroga la miglior AI per il task.
        model: auto|gemini|gemini3|claude|gpt|codex|grok|deepseek|qwen|ollama|free
        mode:  auto|best|cascade|free_only
        """
        result = self._get().ask(prompt, model=model, mode=mode)
        if result["ok"]:
            m = result.get("model", "?").split("/")[-1]
            return "[" + m + "] " + result["text"]
        return "❌ " + result.get("error", "errore")

    # ── Tool: ai_parallel ─────────────────────────────────────────────────────
    def ai_parallel(self, prompt: str, models: str = "") -> str:
        """
        Esegui prompt su più AI in parallelo e ottieni consensus.
        models: es. "gemini,claude,gpt" (separati da virgola)
                   "" = top-3 automatici
        """
        ALIASES = {
            "gemini":   "gemini/gemini-2.5-flash",
            "gemini3":  "gemini/gemini-3.1-pro",
            "claude":   "openrouter/anthropic/claude-sonnet-4-6",
            "gpt":      "openrouter/openai/gpt-5.2",
            "codex":    "openrouter/openai/gpt-5.3-codex",
            "grok":     "openrouter/x-ai/grok-4",
            "deepseek": "openrouter/deepseek/deepseek-v3",
            "qwen":     "openrouter/qwen/qwen3-max",
            "ollama":   "ollama/qwen3:8b",
        }
        model_ids = None
        if models.strip():
            model_ids = [ALIASES.get(m.strip(), m.strip())
                         for m in models.split(",")]

        result = self._get().ask_parallel(prompt, models=model_ids)
        if result["ok"]:
            m    = result.get("model", "?")
            meta = result.get("meta", {})
            n    = meta.get("parallel_count", 1)
            ag   = meta.get("agreement", 0)
            synth = " [SINTESI]" if meta.get("synthesized") else ""
            return ("[PARALLELO " + str(n) + " modelli, accordo=" +
                    str(ag) + synth + "]\n" + result["text"])
        return "❌ " + result.get("error", "errore")

    # ── Tool: ai_status ───────────────────────────────────────────────────────
    def ai_status(self) -> str:
        """Report completo dell'orchestra AI."""
        return self._get().status()

    # ── Tool: ai_models ───────────────────────────────────────────────────────
    def ai_models(self, filter_available: str = "all") -> str:
        """
        Lista modelli disponibili.
        filter_available: all | available | free
        """
        from .ai_router import MODELS_2026
        gw      = self._get()._gw()
        router  = gw.router
        lines   = ["Modelli AI disponibili (Mar 2026):"]

        by_tier = {}
        for mid, meta in MODELS_2026.items():
            t = meta["tier"]
            by_tier.setdefault(t, []).append((mid, meta))

        for tier in sorted(by_tier.keys()):
            lines.append("\n── Tier " + str(tier) + " ──")
            for mid, meta in by_tier[tier]:
                avail   = router._is_available(mid)
                if filter_available == "available" and not avail:
                    continue
                if filter_available == "free" and not meta.get("free_tier"):
                    continue
                icon    = "✅" if avail else "❌"
                free_tag = " [FREE]" if meta.get("free_tier") else ""
                cost    = ("$" + str(meta["cost_in"]) + "/" +
                           str(meta["cost_out"]) + " per 1M")
                intel   = "IQ " + str(meta.get("intelligence", "?"))
                strengths = ", ".join(meta.get("strengths", [])[:3])
                lines.append(
                    icon + " " + meta["display"] + free_tag +
                    " | " + intel + " | " + cost +
                    "\n    → " + strengths
                )

        return "\n".join(lines)

    # ── Tool: git_sync ────────────────────────────────────────────────────────
    def git_sync(self, message: str = "") -> str:
        """Sincronizzazione con GitHub (pull + commit + push)."""
        return self._get().sync_github(message)
